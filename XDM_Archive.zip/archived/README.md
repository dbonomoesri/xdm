# Archive

Contains old JSON schema files that were never used by customers of AEP and no longer loaded in the XDM Registry.
