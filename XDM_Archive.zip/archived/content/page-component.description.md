A page component is a part or module of a `Componentized Page` or included in a `Component Container`.
It contains content fragments and has a specific type.
The type determines how the component will be displayed, rendered, and authored.
