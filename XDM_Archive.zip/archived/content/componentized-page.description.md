A componentized page is a part of a digital experience that is authored though modular components.
Examples for componentized pages include web pages as managed by a web content management system or mobile app pages as managed by a mobile content management system.
Componentized pages are modular (consist of smaller content components), hyperlinked (link to other pages), and include digital assets (like images or videos).
