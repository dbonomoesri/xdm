Encryption policy represents how content in a given part of the repository is encrypted at-rest.
