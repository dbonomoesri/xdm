Versioning policy represents how versioning for content stored in this specific part of the repository is behaving.
