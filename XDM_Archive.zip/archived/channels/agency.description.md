The marketing experience is handed-off to an external agency.
This channel has no specific mechanism and is designed for descriptive purposes only.
Such as, to define experiences for which you want to keep a trace of the population targeted in an external tool
