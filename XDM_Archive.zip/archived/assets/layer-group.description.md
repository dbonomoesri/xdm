Layer group help in preserving the hierarchy of layers in a document.
Users can apply a common style to the group instead of working at individual layers.
A Layer Group can contain layers or other layer groups.
