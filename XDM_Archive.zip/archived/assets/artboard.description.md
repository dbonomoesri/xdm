An artboard works like a piece of paper on a physical desk. You can place elements you are not using on your desk outside the bounds of the paper.
They are still close for easy access, but they don’t interfere with the artwork taking shape on the paper.
XDM artboards work in a similar way.
They contain areas for your artwork that can be are printed or exported.

You can think of an artboard as a special type of layer group.
An artboard clips the contents of any contained elements to its boundaries.
The hierarchy of elements in an artboard is displayed in the Layers panel, together with layers and layer groups.
Artboards can contain layers and layer groups, but not other artboards.
