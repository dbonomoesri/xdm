Layers are like stacked sheets.
Users can add transparency/opacity to see through transparent areas of a layer.
They are used for compositing multiple images, adding text to an image, or adding vector graphic shapes.
Users can also apply a layer style to add a special effect such as a drop shadow or a glow.
