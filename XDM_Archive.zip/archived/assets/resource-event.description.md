A Resource Event is a high-level event that occurred in the processing, editing, or creation of an asset.

Resource Events are typically attached directly to an asset.
