Font is used to describe the typefaces and font files used in a document.
The Font schema groups different font files that belong to the same typeface.
