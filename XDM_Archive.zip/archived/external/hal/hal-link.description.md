> A Link Object represents a hyperlink from the containing resource to a URI.

-- from [JSON Hypertext Application Language, section 5](https://tools.ietf.org/html/draft-kelly-json-hal-08#section-5)
