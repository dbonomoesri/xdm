> The JSON Hypertext Application Language (HAL) is a standard which
> establishes conventions for expressing hypermedia controls, such as
> links, with JSON [RFC4627](https://tools.ietf.org/html/rfc4627).

-- from [JSON Hypertext Application Language draft-kelly-json-hal-08](https://tools.ietf.org/html/draft-kelly-json-hal-08)

This external schema definition allows adding HAL expressions into an existing schema.
