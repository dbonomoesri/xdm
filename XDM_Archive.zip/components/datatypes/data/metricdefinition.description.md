A metric definition is a definition of a measurable or countable quantity.

A metric definition consists of a measurement and a dimension.
For easier identification, metrics have a name and a unique URI that can be used when referring to the metric definition.

Through XDM's extensibility mechanism, new metrics can be defined by extending `Metric Definition`.
