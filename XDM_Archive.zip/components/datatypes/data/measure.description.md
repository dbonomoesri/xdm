A measure is a concrete quantifiable data point of a particular metric.

It has a value, and a unique identifier.
